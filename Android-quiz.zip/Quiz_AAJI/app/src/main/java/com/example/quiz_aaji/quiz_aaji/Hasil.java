package com.example.quiz_aaji.quiz_aaji;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

import butterknife.Bind;
import butterknife.ButterKnife;

public class Hasil extends AppCompatActivity {

    @Bind(R.id.tv_score)
    TextView tv_score;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.hasil);
        ButterKnife.bind(this);


        Bundle bundle=getIntent().getExtras();
        tv_score.setText(String.valueOf(bundle.getInt("score")));

    }
}
