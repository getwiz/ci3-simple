package com.example.quiz_aaji.quiz_aaji;

import android.content.Intent;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.RadioButton;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import butterknife.Bind;
import butterknife.ButterKnife;

public class Soal extends AppCompatActivity {

    Kumpulan_Soal kumpulan_soal;
    Map<String,String> answer;
    List<Integer> dataList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.soal);
        ButterKnife.bind(this);

        kumpulan_soal=new Kumpulan_Soal();
        Map<String,String> question= kumpulan_soal.getQuestion();
        answer=kumpulan_soal.getAnswer();
        Map<String,String> pilihan_a=kumpulan_soal.getPilihan_a();
        Map<String,String> pilihan_b=kumpulan_soal.getPilihan_b();
        Map<String,String> pilihan_c=kumpulan_soal.getPilihan_c();
        Map<String,String> pilihan_d=kumpulan_soal.getPilihan_d();

        //untuk random index
        dataList = new ArrayList<Integer>();
        dataList.size();
        for (int i = 0; i < 2; i++) {
            dataList.add(i);
        }
        Collections.shuffle(dataList);
/*      q1.setText(tes.get(tes.size()));
        dataList.subList(0,5).clear();
        dataList.size();*/

        q1.setText(question.get(String.valueOf(dataList.get(0))));
        q2.setText(question.get(String.valueOf(dataList.get(1))));

        a_1.setText(pilihan_a.get(String.valueOf(dataList.get(0))));
        b_1.setText(pilihan_b.get(String.valueOf(dataList.get(0))));
        c_1.setText(pilihan_c.get(String.valueOf(dataList.get(0))));
        d_1.setText(pilihan_d.get(String.valueOf(dataList.get(0))));

        a_2.setText(pilihan_a.get(String.valueOf(dataList.get(1))));
        b_2.setText(pilihan_b.get(String.valueOf(dataList.get(1))));
        c_2.setText(pilihan_c.get(String.valueOf(dataList.get(1))));
        d_2.setText(pilihan_d.get(String.valueOf(dataList.get(1))));
    }

    @Bind(R.id.q1)
    TextView q1;
    @Bind(R.id.q2)
    TextView q2;

    @Bind(R.id.a_1)
    RadioButton a_1;
    @Bind(R.id.b_1)
    RadioButton b_1;
    @Bind(R.id.c_1)
    RadioButton c_1;
    @Bind(R.id.d_1)
    RadioButton d_1;

    @Bind(R.id.a_2)
    RadioButton a_2;
    @Bind(R.id.b_2)
    RadioButton b_2;
    @Bind(R.id.c_2)
    RadioButton c_2;
    @Bind(R.id.d_2)
    RadioButton d_2;

    @Bind(R.id.n_1)
            TextView n_1;
    @Bind(R.id.n_2)
            TextView n_2;

    int score1=0;
    int score2=0;
    public void cek_s1(View view) {
        // Is the button now checked?
        boolean checked = ((RadioButton) view).isChecked();

        // Check which radio button was clicked
        switch(view.getId()) {
            case R.id.a_1:
                if (checked){
                    score1 =(answer.get(String.valueOf(dataList.get(0)))=="a")? 1 : 0 ;
n_1.setText("A");
                }
                break;
            case R.id.b_1:
                if (checked)
                    score1 =(answer.get(String.valueOf(dataList.get(0)))=="b")? 1 : 0 ;
                n_1.setText("B");
                    break;
            case R.id.c_1:
                if (checked)
                    score1 =(answer.get(String.valueOf(dataList.get(0)))=="c")? 1 : 0 ;
                n_1.setText("C");
                    break;
            case R.id.d_1:
                if (checked)
                    score1 =(answer.get(String.valueOf(dataList.get(0)))=="d")? 1 : 0 ;
                n_1.setText("D");
                    break;
        }
    }

    public void cek_s2(View view) {
        // Is the button now checked?
        boolean checked = ((RadioButton) view).isChecked();

        // Check which radio button was clicked
        switch(view.getId()) {
            case R.id.a_2:
                if (checked)
                    score2 =(answer.get(String.valueOf(dataList.get(1)))=="a")? 1 : 0 ;
                n_2.setText("A");
                    break;
            case R.id.b_2:
                if (checked)
                    score2 =(answer.get(String.valueOf(dataList.get(1)))=="b")? 1 : 0 ;
                n_2.setText("B");
                    break;
            case R.id.c_2:
                if (checked)
                    score2 =(answer.get(String.valueOf(dataList.get(1)))=="c")? 1 : 0 ;
                n_2.setText("C");
                    break;
            case R.id.d_2:
                if (checked)
                    score2 =(answer.get(String.valueOf(dataList.get(1)))=="d")? 1 : 0 ;
                n_2.setText("D");
                    break;
        }
    }

    public void goToHasil(View view){
        Intent intent=new Intent(Soal.this, Hasil.class);
        int totalScore=score1+score2;
        intent.putExtra("score",totalScore);
        startActivity(intent);
    }
}