package com.example.quiz_aaji.quiz_aaji;

import android.util.SparseArray;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by user on 07/04/2016.
 */
public class Kumpulan_Soal {

    public Map<String, String> getQuestion() {
        return question;
    }
    public Map<String, String> getAnswer() {
        return answer;
    }
    public Map<String, String> getPilihan_a() {
        return pilihan_a;
    }
    public Map<String, String> getPilihan_b() {
        return pilihan_b;
    }
    public Map<String, String> getPilihan_c() {
        return pilihan_c;
    }
    public Map<String, String> getPilihan_d() {
        return pilihan_d;
    }

    private Map<String, String> question = new HashMap<String, String>();
    private Map<String, String> answer = new HashMap<String, String>();
    private Map<String, String> pilihan_a = new HashMap<String, String>();
    private Map<String, String> pilihan_b = new HashMap<String, String>();
    private Map<String, String> pilihan_c = new HashMap<String, String>();
    private Map<String, String> pilihan_d = new HashMap<String, String>();

    public Kumpulan_Soal() {

        question.put("0", "Claim Analyst banyak tanggungjawab. Pilih pernyataan yang tidak termasuk dalam tanggungjawabnya.");
        question.put("1", "Banyak komitmen yang dimasukin dalam Cara-Cara Penanganan Klaim (Claims Practices) untuk sebuah perusahaan asuransi. Pilih jawaban yang benar diantara pernyataan dibawah ini.");

        answer.put("0","c");
        answer.put("1","d");

        pilihan_a.put("0","Mengevaluasi kelayakan dari klaim-klaim yang diajukan.");
        pilihan_a.put("1","Menerapkan ketentuan-ketentuan polis tergantung permintaan Tertanggung/Pemegang Polis atau Penerima Manfaat yang ditunjuk dalam polis.");

        pilihan_b.put("0","Mengambil keputusan atas klaim-klaim yang diajukan.");
        pilihan_b.put("1","Melakukan investigasi atas klaim secara acak.");

        pilihan_c.put("0","Membuat arsip dan memberikan nomor kasus atau nomor arsip kepada klaim-klaim yang diajukan.");
        pilihan_c.put("1","Memberikan penjelasan yang singkat dan umum kepada yang mengajukan klaim mengenai klaim-klaim yang manfaatnya tidak bisa dibayarkan atau dibatasi.");

        pilihan_d.put("0","Menentukan orang atau entitas yang akan dibayar.");
        pilihan_d.put("1","Mengizinkan para yang mengajukan klaim untuk menyerahkan informasi pendukung tambahan atas suatu klaim yang ditolak atau dibatasi.");
    }
}
