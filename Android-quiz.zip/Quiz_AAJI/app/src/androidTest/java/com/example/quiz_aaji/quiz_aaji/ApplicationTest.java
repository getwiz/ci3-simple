package com.example.quiz_aaji.quiz_aaji;

import android.app.Application;
import android.test.ApplicationTestCase;

/**
 * <radio_checked href="http://d.android.com/tools/testing/testing_android.html">Testing Fundamentals</radio_checked>
 */
public class ApplicationTest extends ApplicationTestCase<Application> {
    public ApplicationTest() {
        super(Application.class);
    }
}