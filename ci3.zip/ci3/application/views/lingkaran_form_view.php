<html>
    <head>
        <title>Demo Title</title>
        </head>
        <body>
            
            <h2>Luas dan Keliling Lingkaran</h2>
            <form action="http://localhost/ci3/index.php/lingkaran" method="post">
            Masukkan nilai jari-jari:<br/>
            <input type="text" name="jari2" />
            <input type="submit" name="btnSubmit" value="hitung" />
            </form>
            
            </body>
            </html>