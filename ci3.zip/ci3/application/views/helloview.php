<!DOCTYPE html>
<html>
    <head><title>Controller, View, Model</title></head>
    <body>
        <h2><?php echo $teks1; ?> </h2> </br> </br>
        <h2><?php echo $teks2; ?> </h2>
    </body>
</html>