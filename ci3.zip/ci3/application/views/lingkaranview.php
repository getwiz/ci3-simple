<html>
<head>
    <title> Demo demo</title
    </head>
    <body>
        <h2>Model Lingkaran</h2>
        
        Nilai jari-jari:<?php echo $model->get_radius(); ?></br>
        Luas Lingkaran : <?php echo $model->hitung_luas(); ?></br>
        Keliling Lingkaran : <?php echo $model->hitung_keliling(); ?></br>
        </body>
        </html>