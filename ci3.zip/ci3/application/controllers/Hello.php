<?php

class Hello extends CI_Controller{
    public function index(){
    $this->load->model('Hello_model');
    $model=$this->Hello_model;
    
    $s=$model->str;
    $s2=$model->str2;
    
    $data=array('teks1'=>$s,'teks2'=>$s2);
    
    $this->load->view('helloview',$data);
    }
}