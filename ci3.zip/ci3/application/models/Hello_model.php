<?php
class Hello_model extends CI_Model{
    public $str='bray';
    public $str2='bro';
}