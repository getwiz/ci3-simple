<?php

$hal=isset($_GET['hal'])?$_GET['hal']:'';

if($hal=="cr-phbooks"){
	include "halaman/cr-phbooks.php";
}
if($hal=="faq"){
	include "halaman/faq.php";
} elseif($hal=="utama") {
	include "halaman/utama.php";
} elseif($hal=="hasilcari") {
	include "halaman/hasil-cari.php";
}

?>