<?php
    // Menghindari error cannot modify header information
    ob_start(); // Initiate the output buffer
?>

<!DOCTYPE html>
<html>
<head>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta charset="UTF-8">

	<!-- CSS Stylesheet -->
	<link rel="stylesheet" type="text/css" href="<?php echo "$d[alamat_website]/$f[folder]/css/grid12.css" ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo "$d[alamat_website]/$f[folder]/css/responsive.css" ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo "$d[alamat_website]/$f[folder]/css/style.css" ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo "$d[alamat_website]/$f[folder]/css/submenu.css" ?> ">
	<link rel="stylesheet" type="text/css" href="<?php echo "$d[alamat_website]/$f[folder]/css/fixed-nav.css" ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo "$d[alamat_website]/$f[folder]/css/fixed-submenu.css" ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo "$d[alamat_website]/$f[folder]/css/hslide.css" ?>">

</head>
<body>

	<header class="container" id="completeHeader">
	<div class="row col-md-12 panjang-merah"></div>

		<header class="row">
			<div class="abs-bait">
			<figure class="col-md-3 logoo-owl">
				<img id="logo-owl" src="<?php echo "$d[alamat_website]/images/owl_putih.png" ?>" height="113" width="255"/>
			</figure>
			</div>
			
			<figure class="col-md-3 logoo-owl-mobi">
				<img id="logo-owl" src="<?php echo "$d[alamat_website]/images/logo-mobi.png" ?>" height="113" width="255"/>
			</figure>

			<div class="col-md-12 mobi-nav">

					<ul>
					<li>
						<a href="http://localhost/owl/?hal=utama"><img src="images/i-home.png"/></a>
					</li>
					<li id="open-menu">
						<a><img src="images/i-opt.png" data-swap="images/i-close.png"/></a>
						<ul>
						<?php
									  // query menu utama
									  $querymenu = "SELECT * FROM menu WHERE id_parent='0' AND aktif='Y'";
									  $hasilmenu = mysqli_query($link, $querymenu);
									while ($r=mysqli_fetch_array($hasilmenu)) {
										echo "<li><a href=\"$d[alamat_website]/$r[link]\">$r[nama_menu]</a>";
										// query submenu
										$querysubmenu = "SELECT * FROM menu WHERE id_parent='$r[id_menu]' AND aktif='Y'";
										$hasilsubmenu = mysqli_query($link, $querysubmenu);
										$jumlah   = mysqli_num_rows($hasilsubmenu);
										// apabila ada submenu
										if ($jumlah > 0){
										  echo "<ul>";  // <ul> untuk submenu
										  while($w=mysqli_fetch_array($hasilsubmenu)){
											echo "<li><a href=\"$d[alamat_website]/$w[link]\">$w[nama_menu]</a></li>";
										  }
										  echo "</ul>";
										}
										echo "</li>";
									  }
									  
						?>
						
				
						</ul>
					</li>
					<li>
						<form id="search-wrap" action="hasil-pencarian.html" method="post">
							<input id="search-mobi" name="kata" type="text" placeholder="Owl Photo Studio" required>
							<input id="search-btn" type="submit" value=''>
						</form>
						</li>
						<li>

						</li>
					</ul>
			<div id="cancel-search">x</div>
			</div>

			<div class="col-md-12 garis-bawahmenu"></div>
			<!----------------KONTAK ------------------>
			<address class="col-md-9">


			<div id="kontak">
				<figure id="fb-like">
					<a href="#"><img src="<?php echo "$d[alamat_website]/images/fb_like.png"?>"></a>
				</figure>

					<form id="search-wrap" action="hasil-cari.php?module=hasilcari" method="post">

						<input id="search" name="kata" type="text" placeholder="Owl Photo Studio" required>
						<input id="search-btn" type="submit" value=''>

					</form>

				<div id="dl-editor">
					
					<img src="<?php echo "$d[alamat_website]/images/folder_dl.png" ?>" >
					<p>Free Download Owl Photo Editor</p>
				
				</div>
			</div>
			</address>


			<!-- BANNER PROMO SPECIAL OFFER -->
				<figure class="col-md-9 sp">
					<figure id="special_promo">
						<a href="#">Special Promo for New Customers. Click Here</a>
					</figure>
				</figure>

			<!-------------------------- MENU ----------------------->


			<menu class="col-md-9">

				<ul id="menu-nav">

									  <!---------------------- MENU WEBSITE ------------------------------------->

									  <?php
									  // query menu utama
									  $querymenu = "SELECT * FROM menu WHERE id_parent='0' AND aktif='Y'";
									  $hasilmenu = mysqli_query($link, $querymenu);

									  while ($r=mysqli_fetch_array($hasilmenu)) {
										echo "<li><a href=\"$d[alamat_website]/$r[link]\">$r[nama_menu]</a>";
										// query submenu
										$querysubmenu = "SELECT * FROM menu WHERE id_parent='$r[id_menu]' AND aktif='Y'";
										$hasilsubmenu = mysqli_query($link, $querysubmenu);
										$jumlah   = mysqli_num_rows($hasilsubmenu);
										// apabila ada submenu
										if ($jumlah > 0){
										  echo "<ul>";  // <ul> untuk submenu
										  while($w=mysqli_fetch_array($hasilsubmenu)){
											echo "<li><a href=\"$d[alamat_website]/$w[link]\">$w[nama_menu]</a></li>";
										  }
										  echo "</ul>";
										}
										echo "</li>";
									  }
									  ?>
									  </ul>
									  <!---------------------- AKHIR MENU WEBSITE ----------------------------->

				</ul>
			</menu>


		</header>
	</header>


<!-- isi -->
<?php include "isi.php"; ?>
<!-- akhir isi -->

	<footer class="container">
<div class="row col-md-12 mobi" id="scrollToTop">Back to Top</div>
		<div	id="fullFooter">



			<div class="row desktopf">

			<div class="col-md-12 img_bg"></div>
				<div class="col-md-12 color_bg">
					<div class="col-md-1"></div>
						<div class="col-md-10">
							<div class="col-md-2 footer_link">
							<ul>
							<li class="bold">Photobooks</li>
								<?php
								$sql="SELECT nama,link FROM footer_link WHERE kategori='Photobooks' ";
								$hasil=mysqli_query($link,$sql);
								while ($kolom=mysqli_fetch_array($hasil)){
									echo "<li><a href='$kolom[link]' > $kolom[nama] </a></li>";
								};
								?>
							</ul>
							</div>
							<div class="col-md-2 footer_link">
							<ul>
								<li class="bold">Product</li>
								<?php
								$sql="SELECT nama,link FROM footer_link WHERE kategori='Product' ";
								$hasil=mysqli_query($link,$sql);
								while ($kolom=mysqli_fetch_array($hasil)){
									echo "<li><a href='$kolom[link]' > $kolom[nama] </a></li>";
								};
								?>
							</ul>
							</div>
							<div class="col-md-2 footer_link">
							<ul>
								<li class="bold">Gallery</li>
								<?php
								$sql="SELECT nama,link FROM footer_link WHERE kategori='Gallery' ";
								$hasil=mysqli_query($link,$sql);
								while ($kolom=mysqli_fetch_array($hasil)){
									echo "<li><a href='$kolom[link]' > $kolom[nama] </a></li>";
								};
								?>
							</ul>
							</div>
							<div class="col-md-2 footer_link">
							<ul>
								<li class="bold">About Owl</li>
								<?php
								$sql="SELECT nama,link FROM footer_link WHERE kategori='About Owl' ";
								$hasil=mysqli_query($link,$sql);
								while ($kolom=mysqli_fetch_array($hasil)){
									echo "<li><a href='$kolom[link]' > $kolom[nama] </a></li>";
								};
								?>
							</ul>
							</div>
							<div class="col-md-2 footer_link">
							<ul>
								<li class="bold">Your Account</li>
								<?php
								$sql="SELECT nama,link FROM footer_link WHERE kategori='Your Account' ";
								$hasil=mysqli_query($link,$sql);
								while ($kolom=mysqli_fetch_array($hasil)){
									echo "<li><a href='$kolom[link]' > $kolom[nama] </a></li>";
								};
								?>
							</ul>
							</div>
							<div class="col-md-2 footer_link">
							<ul>
							<li class="bold">Connect</li>
								<?php
								$sql="SELECT nama,link FROM footer_link WHERE kategori='Connect' ";
								$hasil=mysqli_query($link,$sql);
								while ($kolom=mysqli_fetch_array($hasil)){
									echo "<li><a href='$kolom[link]' > $kolom[nama] </a></li>";
								};
								?>
							</ul>
							</div>
						</div>
					<div class="col-md-1"></div>
				</div>
			</div>

				<div class="row base-copyright desktopf"	>
				
					<div class="col-md-1">
					</div>
						<div class="col-md-10 copyright">
							<p>
								Copyright@2014 OWL MEMORY KEEPER. Allrights reserved. Branding - Graphic Design - Commercial Photograph. Jakarta, Indonesia.
							</p>
						</div>
						<div class="col-md-1"></div>
				</div>
				
				<div class="row base-copyright mobi"	>
				<div class="col-md-12 img_bg"></div>
					
						<div class="col-md-10 copyright mobi">
							<p>
								Copyright@2014 OWL MEMORY KEEPER. Allrights reserved.<br/>Branding - Graphic Design - <br/>Commercial Photograph. Jakarta, Indonesia.
							</p>
						</div>
						<div class="col-md-1"></div>
				</div>
				
		</div>
	</footer>

<script type="text/javascript" src="<?php echo "$d[alamat_website]/$f[folder]/js/jquery.min.js"?>"></script>

	<script src="<?php echo "$d[alamat_website]/$f[folder]/js/theme-control.js"?>"></script>
	<script type="text/javascript" src="<?php echo "$d[alamat_website]/$f[folder]/js/toggleMenu.js"?>"></script>
	<script type="text/javascript" src="<?php echo "$d[alamat_website]/$f[folder]/js/akordeon.js"?>"></script>
	<script type="text/javascript" src="<?php echo "$d[alamat_website]/$f[folder]/js/slider-cr.js"?>"></script>
	<script type="text/javascript" src="<?php echo "$d[alamat_website]/$f[folder]/js/slider-utama.js"?>"></script>
	</body>
</html>

<?php
    // penutup fungsi ob_start (lihat baris paling atas)
    ob_end_flush(); // Flush the output from the buffer
?>