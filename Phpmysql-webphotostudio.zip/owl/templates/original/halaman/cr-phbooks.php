<div class="container bg-white box-shadow min-height">
	<div class="row">
		<div class="col-md-12 slider-crpb">
		
<ul class="images">

<?php
$sql="SELECT * FROM slider_cr";
$hasil=mysqli_query($link,$sql);
while($row=mysqli_fetch_array($hasil)){
	echo "
				<li><img src=\"images/$row[link_gambar]\">
				<div class=\"hslider-text\">$row[deskripsi]</div></li>";
};
?>

</ul>

<ul class="triggers">
<?php
$sql="SELECT * FROM slider_cr";
$hasil=mysqli_query($link,$sql);
while($row=mysqli_fetch_array($hasil)){
	echo"<li></li>";
};
?>
</ul>


<span class="control prev"><div class="nav-arrow-wrapper-prev"><img src="images/icon-arrow.png"></div></span>
<span class="control next"><div class="nav-arrow-wrapper-next"><img src="images/icon-arrow.png"></div></span>
</div>
</div>



<div class="row col-md-12 cr-wrapper whitespace-bottom">
	<div class="pre-phbook">
	<p class="pre-tittle">PREMIUM PHOTOBOOKS</p>
	<p class="pre-desk">"The best memories will still be remembered as part of the journey of life"</p>
	</div>
	<div class="regular-phbook">
	<p class="reg-tittle">REGULAR PHOTOBOOKS</p>
	<p class="reg-desk">"The best memories will still be remembered as part of the journey of life"</p>
	</div>
</div>




<p class="myriad-bold grey txt-center anyo">Any Occasion</p>
		<div class="any-occasion div-center txt-center whitespace-top">

				<div>
					<p class="myriad-reg grey ">Wedding Photobooks</p>
					<img src="images/cr-small-photo.jpg"></img>
				</div>
				<div>
					<p class="myriad-reg grey">Baby Photobooks</p>
					<img src="images/cr-small-photo.jpg"></img>
				</div>
				<div>
					<p class="myriad-reg grey">Family Photobooks</p>
					<img src="images/cr-small-photo.jpg"></img>
				</div>
				<div>
					<p class="myriad-reg grey">Family Photobooks</p>
					<img src="images/cr-small-photo.jpg"></img>
				</div>
				<div>
					<p class="myriad-reg grey">Travel Photobooks</p>
					<img src="images/cr-small-photo.jpg"></img>
				</div>
			
	</div>
	
<div class="txt-center">
<img class="whitespace-top-big" src="images/cr1.jpg">
<div>
<p class="myriad-bold grey">Photobook yang dapat disesuaikan<p/>

<p class="sourcesans-it grey">Mulai dari pemilihan kertas dengan Fine Art Paper, berbagai ukuran photobook,<br/> jenis penutup dengan bahan LinMaster, Madera-Ginger dan Cover Print <br/> yang dapat menyesuikan dengan foto Anda</p></div>
<img class="whitespace-top" src="images/cr2.jpg">
<div>
<p class="myriad-bold grey">Flawless Lay-Flat Pages</p>
<p class="sourcesans-it grey">Buat photobook Anda terbuka di 2 halaman tanpa jahitan yang mengganggu <br/>dan memungkinkan foto anda bersinar habis dipoles.<br/> tersedia Extra-thick premium paper.</p>

<p class="myriad-bold grey whitespace-top">Ukuran yang tersedia untuk Regular Photobook</p>
<p class="myriad-reg grey">15x10cm, 20x15cm, 20x20cm, 28 x 23 cm, 30x30 cm</p>
</div>

<div>
<div class="h-slider-link-bg"><a class="bg-red">Download Now</a><span class="h-caret-right"></span></div>

<p class="h-slider-link-plus">Order an additional Box</p>
<p class="myriad-reg grey">Juga mendapatkan Box dengan pilihan klasik,<br/>
premium dan juga pilihan Baby box</p>

<img class="whitespace-updown specp" src="images/banner-specialpromo.png">
<p class="myriad-bold grey">PREMIUM & REGULAR PHOTOBOOK</p>
</div>

<img src="images/cr3.jpg">
</div>

</div>
</div>