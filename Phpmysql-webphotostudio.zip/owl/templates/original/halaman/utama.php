	<link rel="stylesheet" type="text/css" href="<?php echo "$d[alamat_website]/$f[folder]/css/slider-utama.css" ?>">
<!---------------------------- CONTENT ------------------------------>
<section class="container box-shadow min-height bg-white">
	<section class="row">
		<section class="col-md-12 fWrapper">

 <!---------------------- HOME SLIDE -------------------------------------->
<div id="utama-desktop">
 <ul class="slidePics">
	<?php
	$sql="SELECT * FROM slider";
	$hasil=mysqli_query($link,$sql);
	while($row=mysqli_fetch_array($hasil)){
	echo "
	<li>
		$row[judul_slide]
		$row[link_gambar]
		$row[deskripsi]
	</li>";
	}
	?>
</ul>

<ul class="slidePointer">
	<?php
	$sql="SELECT * FROM slider";
	$hasil=mysqli_query($link,$sql);
	$a=1;
	while($row=mysqli_fetch_array($hasil)){
	echo "
	<li class=\"list-slidePointer\">
		<div class=\"pita-list\"></div>
		<div class=\"round-list\"></div>
		<div class=\"text-list\">$row[nama_id]</div>
		<div class=\"number-list\">$a</div>
	</li>";
	$a++;
	}
?>
</ul>



<span class="control prevSlide"><div class="nav-arrow-wrapper-prev"><img src="images/icon-arrow.png"></div></span>
<span class="control nextSlide"><div class="nav-arrow-wrapper-next"><img src="images/icon-arrow.png"></div></span>
<div>



	</section>
</section>
</section>