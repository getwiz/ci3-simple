<link rel="stylesheet" type="text/css" href="<?php echo "$d[alamat_website]/$f[folder]/css/faq.css" ?>">

<section class="container bg-white min-height box-shadow">
	<section class="row">
		<section class="col-md-12 faq">
		<div class="col-md-2" id="faq-categories">
		<h1>
		<?php echo "<a id=\"head-link-categories\" href=\"$d[alamat_website]/faq.php\">Kategori</a>" ?>
		</h1>
		<?php
		$sql="SELECT * FROM faq GROUP BY tipe";
		$hasil=mysqli_query($link,$sql);
		while($row=mysqli_fetch_array($hasil)){
			echo "<a href=\"$d[alamat_website]/kategori-faq/$row[tipe].html\">$row[tipe]</a>";
		}
		
		?>
		</div>
		
		<div class="col-md-10">
			<div class="faq-search col-md-12 desktop">
				<form id="search-wrap" action="hasil-pencarian.html" method="post">
						<input id="search" name="kata" type="text" placeholder="Search FAQ..." required>
						<input id="search-btn" type="submit" value="">
				</form>
			</div>
			<div class="col-md-12">
				<ul id="akordeon">
<?php
$kategori=isset($_GET['kategori']) ? $_GET['kategori']:'';

			if(!empty($kategori)){
				$sql2="SELECT * FROM faq WHERE tipe='$kategori' ";
	$hasil2=mysqli_query($link,$sql2);
	while($g=mysqli_fetch_array($hasil2)){
		echo "<li> 
		<a href='#' class='head'>$g[question]</a>
		<div class='content'>$g[answer]</div>
	</li>";
	};
			} else {
				$sql2="SELECT * FROM faq";
$hasil2=mysqli_query($link,$sql2);

while ($g=mysqli_fetch_array($hasil2)){
	echo "<li> 
		<a href='#' class='head'>$g[question]</a>
		<div class='content'>$g[answer]</div>
	</li>";
};
			}
			?>
			</ul>
</div>
		</section>
	</section>
</section>