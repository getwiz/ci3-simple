<link rel="stylesheet" type="text/css" href="<?php echo "$d[alamat_website]/$f[folder]/css/faq.css" ?>">

    <?php
	
	$hasilcari=isset($_GET['hal'])?$_GET['hal']:'';
	
	if ($hasilcari=='hasilcari'){
    ?>
	
	<div class="container bg-white">
	<div class="row">
	<div class="col-md-12 whitespace-top min-height">
	
	<input id="back" type="button" value="< Back" onclick="self.history.back()">
    <?php
      // mencegah XSS
      $kata = htmlentities(htmlspecialchars($_POST['kata']), ENT_QUOTES);

      // pisahkan kata per kalimat lalu hitung jumlah kata
      $pisah_kata = explode(' ',$kata);
      $jml_katakan = (integer)count($pisah_kata);
      $jml_kata = $jml_katakan-1;

      $cari = "SELECT * FROM faq WHERE " ;
      for ($i=0; $i<=$jml_kata; $i++){
        $cari .= "question OR answer LIKE '%$pisah_kata[$i]%'";
        if ($i < $jml_kata ){
          $cari .= " OR ";
        }
      }
      // $cari .= " ORDER BY judul DESC LIMIT 10";
      $hasil  = mysqli_query($link, $cari);
      $ketemu = mysqli_num_rows($hasil);

      if ($ketemu > 0){
        echo "<p class=\"sourcesans-reg\">Ditemukan <b>$ketemu</b> Hasil Pencarian dengan kata <font style='background-color:#ffcccc'><b>$kata</b></font> : </p><br>";
         
		 echo "
					<div class=\"col-md-1\"></div>
					<div class=\"col-md-10\">";
		 echo "<ul id=\"akordeon\">";
        while($t=mysqli_fetch_array($hasil)){        		
			echo "<li> 
						<a href='#' class='head'>$t[question]</a>
						<div class='content'>$t[answer]</div>
						</li>";
        }
		echo "</ul>";
		echo "</div>
					<div class=\"col-md-1\"></div>";
      }
      else{
        echo "<div><h5>Tidak ditemukan hasil pencarian dengan kata <font style='background-color:#ffcccc'>$kata</font></h5></div>";
      }
	}
	?>
	</div>
	</div>
	</div>
	
