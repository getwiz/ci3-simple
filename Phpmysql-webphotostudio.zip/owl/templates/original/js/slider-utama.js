var target;
var slidePointer=$('ul.slidePointer li');
var slidePics=$('ul.slidePics li');
var lastElem=slidePointer.length -1 ;

slidePointer.first().addClass('active');
slidePics.hide().first().show();
function sliderResponse(target){
	slidePics.fadeOut(300).eq(target).fadeIn(300);
	slidePointer.removeClass('active').eq(target).addClass('active');
}

// control
slidePointer.click(function(){
	if(!$(this).hasClass('active')){
		target=$(this).index();
		sliderResponse(target);
		resetTiming();
	}
})
$('.nextSlide').click(function(){
	target=$('ul.slidePointer li.active').index();
	target===lastElem?target=0:target=target+1;
	sliderResponse(target);
	resetTiming();
})
$('.prevSlide').click(function(){
	target=$('ul.slidePointer li.active').index();
	lastElem=slidePointer.length - 1;
	target===0?target=lastElem:target=target - 1;
	sliderResponse(target);
	resetTiming();
})

// autoslide controller
// function sliderTiming(){
	// target=$('ul.slidePointer li.active').index();
	// target===lastElem?target=0:target=target+1;
	// sliderResponse(target);
// }
// var timingRun=setInterval(function(){
	// sliderTiming();
// },2000);
// function resetTiming(){
	// clearInterval(timingRun);
	// timingRun=setInterval(function(){
		// sliderTiming();
	// },2000);
// }


$('#open-menu').click(function(){
	var _this=$('#open-menu img');
	var current= _this.attr('src');
	var swap= _this.attr('data-swap');
_this.attr('src', swap).attr('data-swap',current);
	$('.mobi-nav ul li:hover ul').toggle();
})

$('#scrollToTop').click(function(){
	$(window).scrollTop(0);
})

$('#search-mobi').focusin(function(){
	$('#cancel-search').show();
})

$('#search-mobi').focusout(function(){
	$('#cancel-search').hide();
})

$('#cancel-search').click(function(){
	$('#search-mobi').focusout();
})