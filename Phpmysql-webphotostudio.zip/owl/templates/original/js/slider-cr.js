var indexer;
var triggers=$('ul.triggers li');
var images=$('ul.images li');
var akhirElem=triggers.length -1 ;

triggers.first().addClass('active');
images.hide().first().show();
function slideTo(indexer){
	images.fadeOut(300).eq(indexer).fadeIn(300);
	triggers.removeClass('active').eq(indexer).addClass('active');
}

// control
triggers.click(function(){
	if(!$(this).hasClass('active')){
		indexer=$(this).index();
		slideTo(indexer);
		// resetTiming();
	}
})
$('.next').click(function(){
	indexer=$('ul.triggers li.active').index();
	indexer===akhirElem?indexer=0:indexer=indexer + 1;
	slideTo(indexer);
	// resetTiming();
})
$('.prev').click(function(){
	indexer=$('ul.triggers li.active').index();
	akhirElem=triggers.length - 1;
	indexer===0?indexer=akhirElem:indexer=indexer - 1;
	slideTo(indexer);
	// resetTiming();
})

// autoslide controller
// function sliderTiming(){
	// indexer=$('ul.triggers li.active').index();
	// indexer===akhirElem?indexer=0:indexer=indexer+1;
	// slideTo(indexer);
// }
// var timingRun=setInterval(function(){
	// sliderTiming();
// },2000);
// function resetTiming(){
	// clearInterval(timingRun);
	// timingRun=setInterval(function(){
		// sliderTiming();
	// },2000);
// }