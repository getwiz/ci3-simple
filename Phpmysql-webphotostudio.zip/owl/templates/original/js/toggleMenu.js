// Toggle Menu
$("#completeHeader").show(0);
$("#compactHeader").hide(0);

var	x	=	false	;
$(".toggleMenu").click(function(){
	if(!x){
		$("#compactHeader").show(0,function(){
			$("#completeHeader").hide(0);
			x	=	true	;
		});
		
	}
	else{
		$("#completeHeader").show(0,function(){
			$("#compactHeader").hide(0);
			x	=	false	;
		});
	}
});

// Toggle	Footer
$("#fullFooter").show();
$("#liteFooter").hide();

var	y	=	false	;
$(".toggleFooter").click(function(){
	if(!y){
		$("#liteFooter").show(0,function(){
			$("#fullFooter").hide();
			y	=	true	;
		});
		
	}
	else{
		$("#fullFooter").show(0,function(){
			$("#liteFooter").hide();
			y	=	false	;
		});
	}
});