$slide_1=$("#slide1");
$fade_img=$("#fadein > div");

// default slide
$slide_1.show(0);
$fade_img.not($slide_1).hide(0);

// set index awal
var currentIndex=0;

// untuk mengset index dari nomor
var setIndex=function(index){
return currentIndex=index;
}

// untuk menghitung jumlah slide
var totalSlide=function(){
	var total_img=$fade_img.length;
	var hasil=total_img-1;
	return hasil;
};

var nextIndex=function(){
	var next_index=currentIndex+1;
	if(next_index>totalSlide()){
		return currentIndex=0;
	}
	else{
		return currentIndex=next_index;
	}
}

var previousIndex=function(){
	var prev_index=currentIndex-1;
	if(prev_index<=-1){
		return currentIndex=2;
	}
	else if(prev_index<totalSlide()){
		return currentIndex=prev_index;
	}
};
//untuk mengslide ke arah selanjutnya
$("#lanjut").click(function(){
	$fade_img.eq(nextIndex()).show(0,
	[$fade_img.not(":eq(currentIndex)").hide(0)]);
});

// untuk mengslide ke arah sebelumnya
$("#kembali").click(function(){
	$fade_img.eq(previousIndex()).show(0,
	[$fade_img.not(":eq(currentIndex)").hide(0)]);
});

// fungsi tombol yang mengarah ke suatu slide
$("#one").click(function(){
	$fade_img.eq(setIndex(0)).show(0,
	[$fade_img.not(":eq(currentIndex)").hide(0)]);
});

$("#two").click(function(){
	$fade_img.eq(setIndex(1)).show(0,
	[$fade_img.not(":eq(currentIndex)").hide(0)]);
});

$("#three").click(function(){
	$fade_img.eq(setIndex(2)).show(0,
	[$fade_img.not(":eq(currentIndex)").hide(0)]);
});