var $window=$(window);
var $document=$(document);
var $fixed_nav=$("#fixed_nav");
var fixed_nav_hide=function(){$fixed_nav.css({"display":"none"},{"position":"fixed"},{"z-index":"100"});};
var fixed_nav_show=function(){$fixed_nav.css({"display":"block"},{"position":"fixed"},{"z-index":"100"});};


$window.scroll(function(){
	scroll_pos=$window.scrollTop();
	win_height=$window.height();
	doc_height=$document.height();

	if ( (scroll_pos + win_height > 500) )  {
	fixed_nav_show()
	}
		else{
		fixed_nav_hide()
		};
})

var z=123;
var count;
for (count = 0; count<100;count++){
		$(".tes-doang").append("<p>Astronot sedang naik roket ke bulan.</p>");
		};
		