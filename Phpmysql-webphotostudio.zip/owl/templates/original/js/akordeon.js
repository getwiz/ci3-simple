$('.head').click(function(e){
	e.preventDefault();
	$(this).closest('li').find('.content').slideToggle();
})