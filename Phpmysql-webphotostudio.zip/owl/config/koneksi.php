<?php

function db_connect(){
	
	//Define connection as  a static variable 
	//to avoid connecting more than once
	static $link;

	//try and connect to the database
	//if a connection has not been esthablished yet
	if(!isset($link)){

	//Load configuration as an array.
	//Use the actual location of your configuration file
		$config=parse_ini_file('C:\xampp\htdocs\config.ini');

		$link = mysqli_connect("localhost",$config['username'],$config['password'],$config['dbname']);

	//Handle error - If connection was not successfull
		if($link === false){
			return mysqli_connect_error();
		}
		return $link;
	}
}

function db_query($query){
	//connect to database
	$link=db_connect();
	$result=mysqli_query($link,$query);
	return $result;
}

function db_error(){
	$link=db_connect();
	return mysqli_error($link);
}

function db_select($query){
	$rows = array();
	$result = db_query($query);
	//If query failed, return 'false'
	if ($result === false){
		return false;
	}
	//If query was successful, retrieve all the rows into an array
	while($row=mysqli_fetch_assoc($result)){
		$rows[]=$row;
	}
	return $rows;
}

function db_quote($value){
	$link=db_connect();
	return " ' ".mysqli_real_escape_string($link,$value) . " ' ";
}
?>
