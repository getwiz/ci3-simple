<?php

include "../config/koneksi.php";
$link=db_connect();

// menghindari sql injection
$injeksi_name = mysqli_real_escape_string($link, $name);
$injeksi_password = mysqli_real_escape_string($link, $pw);
	
if (!ctype_alnum($injeksi_name) OR !ctype_alnum($injeksi_password)){
}else{

$query="SELECT * FROM users WHERE username='$name' AND password='$pw' ";

//pengganti mysqli query adalah mysqli prepare
  $login  = mysqli_query($link, $query);
  $ketemu = mysqli_num_rows($login);
  $r      = mysqli_fetch_array($login);

if($ketemu>0){
	echo "berhasil! <br/>";
	session_start();
	$_SESSION['password']=$pw;
	$_SESSION['name']=$name;
	
	 // bikin id_session yang unik dan mengupdatenya agar slalu berubah 
    // agar user biasa sulit untuk mengganti password Administrator 
    $sid_lama = session_id();
	 session_regenerate_id();
    $sid_baru = session_id();
    mysqli_query($link, "UPDATE users SET id_session='$sid_baru' WHERE username='$name' ");
	
	header("Location:dashboard.php");
}
}
?>