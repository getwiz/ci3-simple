<?php
	session_start();
	session_destroy();
	
	echo "Anda berhasil Log out!";
	
	header("refresh:0; url=index.php");
?>