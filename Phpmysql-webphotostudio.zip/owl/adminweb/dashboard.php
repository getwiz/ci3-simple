<?php
session_start();
if(!isset($_SESSION['password']) && !isset($_SESSION['id'])	){
	header("Location: login.php");
} else{
	include "../config/koneksi.php";
	$link=db_connect();
}
?>

<!DOCTYPE html>
<html>
<head>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta charset="UTF-8">

	<link rel="stylesheet" type="text/css" href="css/grid12.css">
	<link rel="stylesheet" type="text/css" href="css/tos.css">
	
</head>
<body class="admin container">
	<header class="row">
	<div class="col-md-12 header"><img src="images/owl_putih.png"/></div>
	
	</header>

	<section class="row">
	
		<nav class="col-md-3 isi-kiri">
		<ul>
		<?php
		include 'left_menu.php';
		?>
		
		</ul>
		<a href="log_out.php" id="log-off"><img src="images/off.png"/></a>
		</nav>
		
		<aside class="col-md-9">
		<?php
		include 'right_content.php';
		?>
		</aside>
	</section>


</body>
</html>