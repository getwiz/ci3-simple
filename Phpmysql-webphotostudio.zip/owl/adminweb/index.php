<!DOCTYPE html>
<html>
<head>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta charset="UTF-8">

	<style>
	body{
		width: 100%;
		position: relative;
	}
	#login label{
	float:left;
	line-height:23px;
	padding-left:10px;
	}

	#login div{
	margin:.5em 25px;
	background:#eee;
	padding:4px;
	-moz-border-radius:3px;
	-webkit-border-radius:3px;
	border-radius:3px;
	text-align:right;
	position:relative;
	}	
	
	#login{
	margin:5em auto;
	background:#fff;
	border:8px solid #eee;
	width:380px;
	-moz-border-radius:5px;
	-webkit-border-radius:5px;
	border-radius:5px;
	-moz-box-shadow:0 0 10px #4e707c;
	-webkit-box-shadow:0 0 10px #4e707c;
	box-shadow:0 0 10px #4e707c;
	text-align:left;
	position:relative;
	}
	
	#login h1{
	background:crimson;
	color:#fff;

	font-size:14px;
	padding:18px 23px;
	margin:0 0 1.5em 0;
	
	}
	
	#login div input{
		left:0;
	}
	
	#login .warning {
    margin: 0;
	    color: rebeccapurple;
}

#login #submit {
    background-color: transparent;
}

#submit input{
	cursor:pointer;
}

.back {
    font-family: sans-serif;
    font-size: 13px;
    margin-left: 2em;
}
	</style>
</head>
<body>

<?php
// define variables and set to empty values
$nameErr = $pwErr = "";
$name = $pw = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  if (empty($_POST["id"])) {
    $nameErr = "* Silahkan isi nama";
  } else {
    $name = test_input($_POST["id"]);
	// check if name only contains letters and whitespace
    if (!preg_match("/^[a-zA-Z ]*$/",$name)) {
      $nameErr = "hanya Huruf  dan Spasi yang dibolehkan"; 
    }
  }
  
  if(empty($_POST["password"])){
	  $pwErr="* Silahkan isi Password";
  }	else	{
	$pw=test_input($_POST["password"]);
  }
}

function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}

if (isset($name) && isset($pw)){
	include "login.php";
}
?>
 

<form id="login" method="post" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']);?>">
<h1>LOGIN ADMINISTRATOR</h1>
<div>
<label>ID</label>
<input type="text" name="id" />
<p class="warning"><?php echo $nameErr ?> </p>
</div>

<div>
<label>Password</label>
<input type="password" name="password" />
<p class="warning"><?php echo $pwErr ?> </p>
</div>

<div id="submit"><input type="submit" value="Log in"/></div>
<p class="back"><a href="http://localhost/tes">Kembali ke Website Utama</a></p>
</form>

</body>
</html>