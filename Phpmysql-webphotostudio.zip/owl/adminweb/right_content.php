<?php

$modul_tujuan=isset($_GET['goto'])?$_GET['goto']:'';

if($modul_tujuan=='modul_faq'){
	include 'modul/modul_faq/faq.php';
}
elseif($modul_tujuan=='modul_slider'){
	include 'modul/modul_slider/slider.php';
}
elseif($modul_tujuan=='admin_home'){
	include 'modul/modul_dashboard_home/dashboard_home.php';
}
elseif($modul_tujuan=='modul_download'){
	include 'modul/modul_download/download.php';
}
elseif($modul_tujuan=='modul_menu'){
	include 'modul/modul_menu/menu.php';
}
elseif($modul_tujuan=='modul_templates'){
	include 'modul/modul_templates/templates.php';
}
elseif($modul_tujuan=='modul_identitas'){
	include 'modul/modul_identitas/identitas.php';
}
elseif($modul_tujuan=='modul_slidercr'){
	include 'modul/modul_slidercr/slidercr.php';
}
elseif($modul_tujuan=='modul_modul'){
	include 'modul/modul_modul/modul.php';
}
else{
	include 'modul/modul_beranda/beranda.php';
}

?>