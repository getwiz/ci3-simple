<?php


$query="SELECT * FROM menu_dashboard ORDER BY level ASC";

if($result=mysqli_query($link,$query)){
	while ($row=mysqli_fetch_array($result)){
		echo "<li><a href='$row[link]' >	$row[nama_modul] </a></li>";
	};
}
?>