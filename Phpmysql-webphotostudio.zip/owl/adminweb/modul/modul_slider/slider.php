<p class="title-modslider">Hal. Utama</P>
<p class="list-slider">List Slider</P>
<table class="tabel-slider">
<tr><th>Nama Slide</th><th>Go</th></tr>
<?php

$sign= 'modul/modul_slider/go_slider.php';

$sql="SELECT * FROM slider";
$hasil=mysqli_query($link,$sql);
while($kolom=mysqli_fetch_array($hasil)){
	echo "<tr>
					<td> $kolom[nama_id]</td>
					<td>
						<a href='?goto=modul_slider&go=edit&id=$kolom[id]'>Edit</a>

						<a href='$sign?where=hapus&id=$kolom[id]' onClick=\"return confirm('Konfirmasi Delete?') \"> Hapus</a>
					</td>
				</tr>";
}
echo "<tr><td colspan='3'><a href='?goto=modul_slider&go=tambah'>Tambah Baris</a></td></tr>";

  // mengatasi variabel yang belum di definisikan (notice undefined index)
  $uploadOk = isset($_GET['uploadstatus']) ? $_GET['uploadstatus'] : 0 ;

if($uploadOk==1){
echo "Upload berhasil";
}
elseif($uploadOk==2){
	echo "Upload tanpa gambar berhasil";
}
?>

<table>

<?php


// mengatasi variabel yang belum di definisikan (notice undefined index)
$go = isset($_GET['go']) ? $_GET['go'] : '';

 // EDIT
if($go=='edit'){
	$sql="SELECT * FROM slider WHERE id='$_GET[id]'	";
	$hasil=mysqli_query($link,$sql);
	$kolom=mysqli_fetch_array($hasil);
	?>

<p class="list-slider">Edit Slide</p>
<form method='POST' action='<?php echo $sign ?>?where=edit&id=<?php echo $_GET['id'] ?>' enctype='multipart/form-data'>
<table class="tabel-editslide">
	<tr>
		<td>Judul Slide</td>
		<td>
			<textarea name="judul_slide" rows="3" cols="50"><?php echo $kolom['judul_slide'] ?></textarea>
		</td>
	</tr>
	
	<tr>
		<td>Nama Slide dalam List Penunjuk</td>
		<td>
			<textarea name="nama_id" rows="1" cols="50"><?php echo $kolom['nama_id'] ?></textarea>
		</td>
	</tr>
	
	<tr><td>Gambar</td><td><textarea name="link_gambar" rows="3" cols="50"><?php echo $kolom['link_gambar'] ?></textarea></td></tr>

	<tr><td>Deskripsi</td><td><textarea name="deskripsi" rows="20" cols="50"><?php echo $kolom['deskripsi'] ?></textarea></td></tr>

	<tr>
	<td colspan='2'>
		<input type='submit' value='Submit'>
		<input type='button' value='Batal' onclick='self.history.back()'>
	</td>
	</tr>

</table>
</form>

<?php }
// TAMBAH
elseif($go=='tambah'){ ?>


<form method="post" action="<?php echo $sign?>?where=tambah" enctype="multipart/form-data">
<table class="tabel-modul">
<p class="list-modul">Tambah Slide</p>

<tr>
	<td>Nama Slide dalam Daftar</td>
	<td><textarea name="nama_id" rows="1" cols="30"></textarea></td>
</tr>

<tr>
	<td>Judul Slide</td>
	<td><textarea name="judul_slide" rows="1" cols="30"></textarea></td>
</tr>

<tr>
	<td>Gambar</td>
	<td><textarea name="link_gambar" rows="1" cols="30"></textarea></td>
</tr>

<tr>
	<td>Deskripsi</td>
	<td><textarea name="deskripsi" id="textEditor" rows="10" cols="30"></textarea></td>
</tr>

<tr>
	<td colspan="2"><input type="submit" value="Submit"/></td>
</tr>

</table>
</form>

<?php } ?>