<?php
include '../../../config/koneksi.php';
$link=db_connect();

// EDIT
if($_GET['where']=='edit'){

	
	$judul_slide=mysqli_real_escape_string($link,$_POST['judul_slide']);
	$nama_id=mysqli_real_escape_string($link,$_POST['nama_id']);
	$deskripsi=mysqli_real_escape_string($link,$_POST['deskripsi']);
	$link_gambar=mysqli_real_escape_string($link,$_POST['link_gambar']);
	
	$sql = "	UPDATE slider SET 	judul_slide='$judul_slide',
				nama_id='$nama_id',
				link_gambar='$link_gambar',
				deskripsi='$deskripsi'
				WHERE id='$_GET[id]'	";
	if(mysqli_query($link,$sql)){
		header("Location:../../../adminweb/dashboard.php?goto=modul_slider&uploadstatus=$uploadOk");
		}
}
 
// TAMBAH
 elseif($_GET['where']=='tambah'){
	
	$nama_id=mysqli_real_escape_string($link,$_POST['nama_id']);
	$judul_slide=mysqli_real_escape_string($link,$_POST['judul_slide']);
	$deskripsi=mysqli_real_escape_string($link,$_POST['deskripsi']);
	$link_gambar=mysqli_real_escape_string($link,$_POST['link_gambar']);
	
	$sql="INSERT INTO slider (nama_id, judul_slide, link_gambar, deskripsi)
				VALUES (	
						'$nama_id',
						'$judul_slide',
						'$link_gambar',
						'$deskripsi')";
	$tambahOk=0;
		
		if(mysqli_query($link,$sql)){
			$tambahOk=2;
			header("Location:../../../adminweb/dashboard.php?goto=modul_slider&uploadstatus=$tambahOk");
			}
			
// HAPUS
} elseif($_GET['where']=='hapus'){

	$sql = "DELETE FROM slider WHERE id=$_GET[id]";
	$hapusOk=0;
		
		if(mysqli_query($link,$sql)){
			$hapusOk=3;
			header("Location:../../../adminweb/dashboard.php?goto=modul_slider&uploadstatus=$hapusOk");
			}
		} 
	?>