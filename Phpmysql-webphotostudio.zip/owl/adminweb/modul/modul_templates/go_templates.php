<?php

include '../../../config/koneksi.php';
$link=db_connect();

  $module = $_GET['goto'];
  $act    = $_GET['act'];

  // Hapus templates
  if ($act=='hapus'){
    $hapus = "DELETE FROM templates WHERE id_templates='$_GET[id]'";
    mysqli_query($link, $hapus);
    
    header("Location:http://localhost/owl/adminweb/dashboard.php?goto=modul_templates");
  }

  // Input templates
  if ($act=='input'){
    $nama_templates = $_POST['nama_templates'];
    $pembuat        = $_POST['pembuat'];
    $folder         = $_POST['folder'];
    
    $input = "INSERT INTO templates(nama_templates, pembuat, folder) VALUES('$nama_templates', '$pembuat', '$folder')";
    if(mysqli_query($link, $input)){
 header("Location:http://localhost/owl/adminweb/dashboard.php?goto=modul_templates&status=1");
  } else {
	 header("Location:http://localhost/owl/adminweb/dashboard.php?goto=modul_templates&status=2"); 
  }
  }

  // Update templates
  elseif ($act=='update'){
    $id             = $_POST['id'];
    $nama_templates = $_POST['nama_templates'];
    $pembuat        = $_POST['pembuat'];
    $folder         = $_POST['folder'];
    
    $update = "UPDATE templates SET nama_templates='$nama_templates', pembuat='$pembuat', folder='$folder' WHERE id_templates='$id'";
    mysqli_query($link, $update);

 header("Location:http://localhost/owl/adminweb/dashboard.php?goto=modul_templates");
  }

  // Aktifkan templates
  elseif ($act=='aktifkan'){
    $query1 = mysqli_query($link, "UPDATE templates SET aktif='Y' WHERE id_templates='$_GET[id]'");
    $query2 = mysqli_query($link, "UPDATE templates SET aktif='N' WHERE id_templates!='$_GET[id]'");
 header("Location:http://localhost/owl/adminweb/dashboard.php?goto=modul_templates");
  }
?>
