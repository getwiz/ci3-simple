<?php
include '../../../config/koneksi.php';
$link=db_connect();
$pilar="Location:../../../adminweb/dashboard.php?goto=modul_modul";
// EDIT
if($_GET['where']=='edit'){

	
	$nama_modul=mysqli_real_escape_string($link,$_POST['nama_modul']);
	$links=mysqli_real_escape_string($link,$_POST['link']);
	$level=mysqli_real_escape_string($link,$_POST['level']);
	
	$sql = "	UPDATE menu_dashboard SET 	nama_modul='$nama_modul',
											link='$links',
											level='$level'
				WHERE id='$_GET[id]'	";
	$status='';
	
	if(mysqli_query($link,$sql)){
		$status='edit';
		header("$pilar&status=$status");
		} else {
			$status='gagal';
			header("$pilar&status=$status");
		}}
 
// TAMBAH
 elseif($_GET['where']=='tambah'){
	
	$nama_modul=mysqli_real_escape_string($link,$_POST['nama_modul']);
	$links=mysqli_real_escape_string($link,$_POST['link']);
	$level=mysqli_real_escape_string($link,$_POST['level']);
	
	$sql="INSERT INTO menu_dashboard (nama_modul, link, level)
				VALUES (	
						'$nama_modul',
						'$links',
						'$level' )";
			$status='';
		
		if(mysqli_query($link,$sql)){
			$status='tambah';
			header("$pilar&status=$status");
			} else {
			$status='gagal';
			header("$pilar&status=$status");
		}
			
// HAPUS
} elseif($_GET['where']=='hapus'){

	$sql = "DELETE FROM menu_dashboard WHERE id=$_GET[id]";
	$status='';
		
		if(mysqli_query($link,$sql)){
			$status='hapus';
			header("$pilar&status=$status");
			} else {
			$status='gagal';
			header("$pilar&status=$status");
		}
			
			
} 
	?>