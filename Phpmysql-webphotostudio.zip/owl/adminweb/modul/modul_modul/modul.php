<p class="title-modslider">Hal. Utama</P>
<p class="list-slider">List Slider</P>
<table class="tabel-slider">
<tr><th>Nama Slide</th><th>Link</th><th>Level</th><th>Go</th></tr>
<?php

$sign= 'modul/modul_modul/go_modul.php';

$sql="SELECT * FROM menu_dashboard";
$hasil=mysqli_query($link,$sql);
while($kolom=mysqli_fetch_array($hasil)){
	echo "<tr>
			<td> $kolom[nama_modul]</td>
			<td>$kolom[link]</td>
			<td>$kolom[level]</td>
			<td>
				<a href='?goto=modul_modul&go=edit&id=$kolom[id]'>Edit</a>

				<a href='$sign?where=hapus&id=$kolom[id]' onClick=\"return confirm('Konfirmasi Delete?') \"> Hapus</a>
			</td>
		</tr>";
}
echo "<tr><td colspan='4'><a href='?goto=modul_modul&go=tambah'>Tambah Baris</a></td></tr>";

  // mengatasi variabel yang belum di definisikan (notice undefined index)
  $status = isset($_GET['status']) ? $_GET['status'] : 'nothing';

if($status=='edit'){
echo "Edit berhasil";
}
elseif($status=='hapus'){
	echo "Penghapusan berhasil";
}
elseif($status=='tambah'){
	echo "Penambahan berhasil";
}
elseif($status=='gagal'){
	echo "Update gagal";
}
?>

<table>

<?php


// mengatasi variabel yang belum di definisikan (notice undefined index)
$go = isset($_GET['go']) ? $_GET['go'] : '';

 // EDIT
if($go=='edit'){
	$sql="SELECT * FROM menu_dashboard WHERE id='$_GET[id]'	";
	$hasil=mysqli_query($link,$sql);
	$kolom=mysqli_fetch_array($hasil);
	?>

<p class="list-slider">Edit Slide</p>
<form method='POST' action='<?php echo $sign ?>?where=edit&id=<?php echo $_GET['id'] ?>' enctype='multipart/form-data'>
<table class="tabel-editslide">
	<tr>
		<td>Nama Modul</td>
		<td>
			<textarea name="nama_modul" rows="1" cols="50"><?php echo $kolom['nama_modul'] ?></textarea>
		</td>
	</tr>
	
	<tr>
		<td>Link</td>
		<td>
			<textarea name="link" rows="2" cols="50"><?php echo $kolom['link'] ?></textarea>
		</td>
	</tr>
	
	<tr><td>Level Modul</td><td><textarea name="level" rows="1" cols="50"><?php echo $kolom['level'] ?></textarea></td></tr>


	<tr>
	<td colspan='2'>
		<input type='submit' value='Submit'>
		<input type='button' value='Batal' onclick='self.history.back()'>
	</td>
	</tr>

</table>
</form>

<?php }
// TAMBAH
elseif($go=='tambah'){ ?>


<form method="post" action="<?php echo $sign?>?where=tambah" enctype="multipart/form-data">
<table class="tabel-modul">
<p class="list-modul">Tambah Slide</p>

<tr>
	<td>Nama Modul</td>
	<td><textarea name="nama_modul" rows="1" cols="30"></textarea></td>
</tr>

<tr>
	<td>Link</td>
	<td><textarea name="link" rows="2" cols="30"></textarea></td>
</tr>

<tr>
	<td>Level</td>
	<td><textarea name="level" rows="1" cols="30"></textarea></td>
</tr>

<tr>
	<td colspan="2"><input type="submit" value="Submit"/></td>
</tr>

</table>
</form>

<?php } ?>