<?php
include '../../../config/koneksi.php';
 $link=db_connect();
 
  $modul = $_GET['goto'];

  $id             = $_POST['id'];
  $nama_pemilik   = $_POST['nama_pemilik'];
  $judul_website  = $_POST['judul_website'];
  $alamat_website = $_POST['alamat_website']; 
  $meta_deskripsi = $_POST['meta_deskripsi'];
  $meta_keyword   = $_POST['meta_keyword'];
  $email          = $_POST['email'];
  $facebook       = $_POST['facebook'];
  $twitter        = $_POST['twitter'];
  $twitter_widget = addslashes($_POST['twitter_widget']);
  $googleplus     = $_POST['googleplus'];
  $googlemap      = $_POST['googlemap'];

  $lokasi_file    = $_FILES['fupload']['tmp_name'];
  $nama_file      = $_FILES['fupload']['name'];

  // Apabila gambar favicon tidak diganti (atau tidak ada gambar yang di upload)
  if (empty($lokasi_file)){
    $edit = "UPDATE identitas SET nama_pemilik   = '$nama_pemilik',
                                  judul_website  = '$judul_website',
                                  alamat_website = '$alamat_website',
                                  meta_deskripsi = '$meta_deskripsi',
                                  meta_keyword   = '$meta_keyword',
                                  email          = '$email',
                                  twitter        = '$twitter',
                                  twitter_widget = '$twitter_widget',
                                  googleplus     = '$googleplus',
                                  googlemap      = '$googlemap',
                                  facebook       = '$facebook'
                            WHERE id_identitas   = '$id'";
    mysqli_query($link, $edit);
    header("Location:../../../adminweb/dashboard.php?goto=modul_identitas");
  }
  else{
    // folder untuk gambar favicon ada di root
    $folder = "../../../images";
    $file_upload = $folder . $nama_file;
    // upload gambar favicon
    move_uploaded_file($_FILES["fupload"]["tmp_name"], $file_upload);

    $edit = "UPDATE identitas SET nama_pemilik   = '$nama_pemilik',
                                  judul_website  = '$judul_website',
                                  alamat_website = '$alamat_website',
                                  meta_deskripsi = '$meta_deskripsi',
                                  meta_keyword   = '$meta_keyword',
                                  email          = '$email',
                                  twitter        = '$twitter',
                                  twitter_widget = '$twitter_widget',
                                  googleplus     = '$googleplus',
                                  googlemap      = '$googlemap',
                                  facebook       = '$facebook'
                            WHERE id_identitas   = '$id'";
    mysqli_query($link, $edit);
        header("Location:../../../adminweb/dashboard.php?goto=$modul");
  }
?>
