<?php


$sql="SELECT * FROM faq";
$hasil=mysqli_query($link,$sql);
$sign = 'modul/modul_faq/go-faq.php';

?>

<table class="tabel-modul">
<p class="titel-modul">FAQ Editor</p>
<p class="list-modul">List FAQ</p>
<?php
$urutan=1;
while($g=mysqli_fetch_array($hasil)){

echo "
			<tr >
			<td rowspan=\"2\">$urutan</td>
				<td>Pertanyaan</td>
				<td>$g[question]</td>
				<td rowspan=\"2\">$g[tipe]</td>
			</tr>
			<tr>
				<td>Answer</td>
				<td>
					$g[answer]
					<a href=\"?goto=modul_faq&go=edit&id=$g[id]\">Edit</a>
					<a href=\"$sign?where=hapus&id=$g[id]\" onClick=\"return confirm ('Konfirmasi Delete?')\" /> Hapus</a>
					
				</td>
			</tr>";
$urutan++;
}
echo "<tr><td colspan='4'><a href='?goto=modul_faq&go=tambah'>Tambah Baris</a></td></tr>";

echo "</table>";
$status=isset($_GET['status'])?$_GET['status']:'';

if ($status==1){
	echo "<div id='status'>Edit Berhasil</div>";
} elseif ($status==2){
	echo "<div id='status'>Baris Berhasil Ditambahkan</div>";
} elseif ($status==3){
	echo "<div id='status'>Hapus Berhasil</div>";
}


$go=isset($_GET['go'])?$_GET['go'] : '';
if($go=='edit'){

	$id=$_GET['id'];
	$sql="SELECT * FROM faq WHERE id='$id'	";
	$hasil=mysqli_query($link,$sql);
	$kolom=mysqli_fetch_array($hasil);
	?>

<p class="list-modul">Edit</p>
<form method="post" action="<?php echo $sign?>?where=edit&id=<?php echo $id ?>" enctype="multipart/form-data">
<table class="tabel-modul">
<tr>
	<td>Pertanyaan</td>
	<td><textarea name="question" rows="1" cols="30"><?php echo $kolom['question'] ?> </textarea></td>
</tr>

<tr>
	<td>Answer</td>
	<td><textarea name="answer" rows="10" cols="30"><?php echo $kolom['answer'] ?></textarea></td>
</tr>

<tr>
	<td>Kategori</td>
	<td><textarea name="kategori" rows="1" cols="30"><?php echo $kolom['tipe'] ?></textarea></td>
</tr>

<tr>
	<td colspan="2"><input type="submit" value="Submit"/></td>
</tr>
</table>
</form>

<?php }
elseif($go=='tambah'){ ?>

<p class="list-modul">Tambah List</p>

<form method="post" action="<?php echo $sign?>?where=tambah" enctype="multipart/form-data">
<table  class="tabel-modul">
<tr><td colspan="2">Tambah Baris Akordeon</td></tr>
<tr>
	<td>Pertanyaan</td>
	<td><textarea name="question" rows="1" cols="30"></textarea></td>
</tr>

<tr>
	<td>Answer</td>
	<td><textarea name="answer" rows="10" cols="30">	</textarea></td>
</tr>

<tr>
	<td>Kategori</td>
	<td><textarea name="kategori" rows="1" cols="30">	</textarea></td>
</tr>

<tr>
	<td colspan="2"><input type="submit" value="Submit"/></td>
</tr>

</table>
</form>

<?php } ?>
