<?php
include '../../../config/koneksi.php';
$link=db_connect();
$pilar="Location:../../../adminweb/dashboard.php?goto=modul_faq";

if($_GET['where']=='edit'){
	
	$question=$_POST['question'];
	$answer=$_POST['answer'];
	$kategori=$_POST['kategori'];
	
	$sql = "	UPDATE faq SET 	question='$question', 
																answer='$answer',
																tipe='$kategori'
						WHERE id='$_GET[id]'	";
						
	$editOk=0;
		
		if(mysqli_query($link,$sql)){
			$editOk=1;
			header("$pilar&status=$editOk");
			}
}
elseif($_GET['where']=='tambah'){
	// include "../config/koneksi.php";
	$question=$_POST['question'];
	$answer=$_POST['answer'];
	$kategori=$_POST['kategori'];
	$sql="INSERT INTO faq (question, answer,tipe)
				VALUES ('$question',
								'$answer',
								'$kategori')";
	$tambahOk=0;
		
		if(mysqli_query($link,$sql)){
			$tambahOk=2;
			header("$pilar&status=$tambahOk");
			}
}

elseif($_GET['where']=='hapus'){
// include "../config/koneksi.php";
	$sql = "DELETE FROM faq WHERE id=$_GET[id]";
	$hapusOk=0;
		
		if(mysqli_query($link,$sql)){
			$hapusOk=3;
			header("$pilar&status=$hapusOk");
			}
} 
?>