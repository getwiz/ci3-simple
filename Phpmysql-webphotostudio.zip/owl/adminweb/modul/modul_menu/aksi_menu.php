<?php
include "../../../config/koneksi.php";
$link=db_connect();

  $module = $_GET['module'];
  $act    = $_GET['act'];

  // Hapus menu
  if ($module=='menu' AND $act=='hapus'){
    $query = "DELETE FROM menu WHERE id_menu='$_GET[id]'";
    mysqli_query($link, $query);
  header("Location:../../../adminweb/dashboard.php?goto=modul_menu");
  }

  // Input menu
  elseif ($module=='menu' AND $act=='input'){
    $nama_menu = $_POST['nama_menu'];
    $link_menu      = $_POST['link'];
    $id_parent = $_POST['id_parent'];

    $input = "INSERT INTO menu(nama_menu, 
                               link,
                               id_parent) 
                        VALUES('$nama_menu', 
                               '$link_menu',
                               '$id_parent')";
    mysqli_query($link, $input);

    header("Location:../../../adminweb/dashboard.php?goto=modul_menu");
  } 

  // Update menu
  elseif ($module=='menu' AND $act=='update'){
    $id        = $_POST['id'];
    $nama_menu = $_POST['nama_menu'];
    $link_menu      = $_POST['link'];
    $id_parent = $_POST['id_parent'];
    $aktif     = $_POST['aktif'];

    $update = "UPDATE menu SET nama_menu = '$nama_menu',
                               link      = '$link_menu', 
                               aktif     = '$aktif', 
                               id_parent = '$id_parent'
                         WHERE id_menu   = '$id'";
    mysqli_query($link, $update);
      
    header("location:../../../adminweb/dashboard.php?goto=modul_menu");
  }
?>
