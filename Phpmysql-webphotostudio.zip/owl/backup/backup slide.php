	// <ul>
						// <li><img src="image/pita.png"><a id="one" href="#"><img src="image/bullet.png"><span>Home</span></a>
						// <li><img src="image/pita.png"><a id="two" href="#"><img src="image/bullet.png"><span>Photo Prints</span></a>
						// <li><img src="image/pita.png"><a id="three" href="#"><img src="image/bullet.png"><span>Canvas Prints</span></a>
						// </ul>
					// </nav>

					// <h1 class="col-md-10 title_slide">Photobook Print</h1>
				// </nav>
// <div id="fadein" class="col-md-12	tez">
						// <div  id="slide1">
							// <img src="image/home.png">
									// <div class="slide-deskripsi">
										// <span>
											// <span class="h2">1. Make your memory<br/></span>
											// <span class="h3">Come to life<br/></span>
											Create a on-of-a-kind journey of imagination<br/>
											thas's as unique as your love<br/><br/>
										</span>
										<span>
											"The best wedding photobook,<br/>
											with fantastic quality, so proud<br/>
											to present our wedding picture."<br/><br/>
										</span>
										<span>
												"Giving final touches impressive<br/>
												when we give as special gift"<br/>
										// </span>
									// </div>
							// </img>
						// </div>
							// <div id="slide2">
								// <img src="image/photo_prints.png">
									// <div class="slide-deskripsi">
											// <span>
												// <span class="h2">2. Make your memory<br/></span>
												// <span class="h3">Come to me<br/></span>
												// Create a on-of-a-kind journey of imagination<br/>
												// thas's as unique as your love<br/><br/>
											// </span>
											// <span>
												// "The wauw wedding photobook,<br/>
												// with fantastic quality, so proud<br/>
												// to present our wedding picture."<br/><br/>
											// </span>
											// <span>
													// "Giving final touches impressive<br/>
													// when we give as special gift"<br/>
											// </span>
										// </div>
								// </img>
							// </div>
							// <div id="slide3">
								// <img  src="image/canvas_print.png">
										// <div class="slide-deskripsi">
											// <span>
												// <span class="h2">3. Make your memory<br/></span>
												// <span class="h3">Come to you<br/></span>
												// Create a on-of-a-kind journey of imagination<br/>
												// thas's as unique as your love<br/><br/>
											// </span>
											// <span>
												// "The wow wedding photobook,<br/>
												// with fantastic quality, so proud<br/>
												// to present our wedding picture."<br/><br/>
											// </span>
											// <span>
													// "Giving final touches impressive<br/>
													// when we give as special gift"<br/>
											// </span>
										// </div>
								// </img>
							// </div>
						// </div>

						// <nav	id="slide-arrow">
							// <ul>
							// <li><a id="lanjut" href="#"><img	src="image/aim-arrow.png"/></a></li>
							// <li><a id="kembali" href="#"><img	src="image/aim-arrow.png"/></a></li>
							// </ul>
						// </nav>

					</section>
					
					
					<!-- SLIDES -->
				<nav class="row">
					<nav id="slider_name" class="col-md-2">
						<ul>
						<li><img src="image/pita.png"><a id="one" href="#"><img src="image/bullet.png"><span>Home</span></a>
						<li><img src="image/pita.png"><a id="two" href="#"><img src="image/bullet.png"><span>Photo Prints</span></a>
						<li><img src="image/pita.png"><a id="three" href="#"><img src="image/bullet.png"><span>Canvas Prints</span></a>
						</ul>
					</nav>

					<h1 class="col-md-10 title_slide">Photobook Print</h1>
				</nav>

			<section class="row">
					<section class="col-md-12">
						
			</section>
			<div class="col-md-12 tes-doang"></div>
		</section>