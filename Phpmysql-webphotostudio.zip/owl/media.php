<?php

include "config/koneksi.php";
  $link=db_connect();
include "config/library.php";
include "config/class_paging.php";

// Mengambil data identitas website
$query = "SELECT * FROM identitas"; 
$hasil = mysqli_query($link, $query);  
$d     = mysqli_fetch_array($hasil);

// Memilih template yang aktif saat ini
$querytemplate = "SELECT folder FROM templates WHERE aktif='Y'"; 
$pilihtemplate = mysqli_query($link, $querytemplate);  
$f              = mysqli_fetch_array($pilihtemplate);

include "$f[folder]/template.php"; 

?>