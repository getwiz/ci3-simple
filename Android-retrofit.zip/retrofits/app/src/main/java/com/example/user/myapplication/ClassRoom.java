package com.example.user.myapplication;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by user on 01/04/2016.
 */
public class ClassRoom {
    public List<Student> getData() {
        return data;
    }

    public void setData(List<Student> data) {
        this.data = data;
    }

    private List<Student> data=new ArrayList<>();

}
