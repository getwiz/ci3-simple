package com.example.user.myapplication;

/**
 * Created by user on 01/04/2016.
 */
public class Student {


    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public String getScore() {
        return score;
    }

    public void setScore(String score) {
        this.score = score;
    }

    private String nama;
    private String score;

}
