package com.example.user.myapplication;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;
import butterknife.OnTextChanged;
import retrofit.Call;
import retrofit.Callback;
import retrofit.GsonConverterFactory;
import retrofit.Response;
import retrofit.Retrofit;

public class MainActivity extends AppCompatActivity {


    Retrofit retrofit;
    ApiJson apiJson;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ButterKnife.bind(this);

        retrofit = new Retrofit.Builder()
                .baseUrl("https://api.myjson.com").addConverterFactory(GsonConverterFactory.create())
                .build();

        apiJson = retrofit.create(ApiJson.class);
    }

    private String name="";
    private int score=0;

    @OnTextChanged(R.id.e_nama) void input_nama(CharSequence t){
        name=String.valueOf(t);
    }

    @OnTextChanged(R.id.e_nilai) void input_nilai(CharSequence t){
        score=Integer.parseInt(String.valueOf(t));
    }

    List<Student> data=new ArrayList<>();
    Student student =new Student();
    ClassRoom classRoom=new ClassRoom();

    public void sendFile(View view){

        final ProgressDialog mProgressDialog = new ProgressDialog(this);
        mProgressDialog.setIndeterminate(true);
        mProgressDialog.setMessage("Loading...");
        mProgressDialog.show();

        //dapatkan dulu data dari json
        Call<ClassRoom> get_data=apiJson.getBody();
        get_data.enqueue(new Callback<ClassRoom>() {
            @Override
            public void onResponse(Response<ClassRoom> response, Retrofit retrofit) {
                data = response.body().getData();

                student.setNama(name);
                student.setScore(String.valueOf(score));
                data.add(student);
                classRoom.setData(data);

                //send back to json
                Call<ClassRoom> call=apiJson.putBody(classRoom);
                call.enqueue(new Callback<ClassRoom>() {
                    @Override
                    public void onResponse(Response<ClassRoom> response, Retrofit retrofit) {

                        mProgressDialog.dismiss();
                        Toast.makeText(getApplicationContext(),"Nilai sudah tersubmit", Toast.LENGTH_SHORT).show();
                    }

                    @Override
                    public void onFailure(Throwable t) {
                        mProgressDialog.dismiss();
                        Toast.makeText(getApplicationContext(), t.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
            }

            @Override
            public void onFailure(Throwable t) {

            }
        });




    }
}
