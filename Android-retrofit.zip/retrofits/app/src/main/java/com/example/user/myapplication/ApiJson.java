package com.example.user.myapplication;

import retrofit.Call;
import retrofit.http.Body;
import retrofit.http.GET;
import retrofit.http.PUT;

/**
 * Created by user on 01/04/2016.
 */

public interface ApiJson {
    @PUT("/bins/5bk82")
    Call<ClassRoom> putBody(@Body ClassRoom classRoom);

    @GET("/bins/5bk82")
    Call<ClassRoom> getBody();
}
